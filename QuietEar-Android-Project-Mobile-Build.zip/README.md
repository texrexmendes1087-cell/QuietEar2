# QuietEar (prova de conceito Android)

Projeto inicial para Samsung Galaxy A56 + fones Bluetooth UNICO EP2808.

## O que esta versão faz
- Capta o microfone do telemóvel a 16 kHz mono.
- Tenta ativar `NoiseSuppressor` do Android, se o dispositivo disponibilizar esse efeito.
- Aplica uma porta de ruído adaptativa muito simples.
- Reproduz o resultado através de `AudioTrack` com uso `MEDIA`, sem pedir foco de áudio, para tentar coexistir com Spotify.

## Limitações importantes
- Isto **não é ANC** e não gera anti-ruído calibrado.
- A porta de ruído reduz sobretudo sons baixos/constantes; pode cortar partes de fala e não remove todos os ruídos.
- O `NoiseSuppressor` do Android é normalmente orientado a voz/chamadas e pode não estar disponível ou funcionar igual em todos os dispositivos.
- A coexistência com Spotify depende do Android, Samsung One UI e da aplicação que está a tocar.
- O áudio do microfone pode ter atraso. O microfone é o do telemóvel, não os microfones dos auriculares.
- A aplicação só funciona enquanto a Activity está aberta nesta primeira versão. Não tem serviço em segundo plano.
- Não usar ao atravessar ruas, conduzir ou em situações em que seja importante ouvir o ambiente.

## Compilar
1. Instalar Android Studio.
2. Abrir a pasta `QuietEar` no Android Studio.
3. Aceitar a sincronização do Gradle.
4. Ligar o Galaxy A56 por USB e ativar as opções de programador + depuração USB.
5. Escolher **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Instalar a APK gerada e conceder permissão do microfone.

Requisitos de compilação: Android Studio recente, JDK 17 e Android SDK 35.

## Próximos passos de desenvolvimento
- Medir latência de captura e reprodução no A56.
- Testar rota Bluetooth A2DP e coexistência com Spotify.
- Substituir a porta de ruído por um modelo de redução de ruído neural (por exemplo, RNNoise ou DeepFilterNet), após validar desempenho e latência no aparelho.
- Adicionar serviço em primeiro plano e notificação persistente se a utilização em segundo plano for necessária.

## Compilar sem computador (GitHub Actions)
1. No telemóvel, cria uma conta gratuita em GitHub, se ainda não tiveres.
2. No navegador do telemóvel, cria um repositório novo e carrega o conteúdo deste ZIP.
3. Abre o separador **Actions** do repositório.
4. Seleciona **Build QuietEar APK** e toca em **Run workflow**.
5. Quando terminar, abre a execução e descarrega o artefacto **QuietEar-debug-apk**.
6. Extrai o ZIP do artefacto e instala `app-debug.apk`. Poderá ser necessário permitir instalação desta origem nas definições Android.

A compilação em nuvem é gratuita dentro dos limites do GitHub Actions. O workflow utiliza Gradle instalado no runner.
