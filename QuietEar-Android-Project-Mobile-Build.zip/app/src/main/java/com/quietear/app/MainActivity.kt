package com.quietear.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.app.Activity
import android.content.Context
import android.os.Process
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.max
import kotlin.math.sqrt

class MainActivity : Activity() {
    private var engine: QuietEarEngine? = null
    private lateinit var status: TextView
    private lateinit var level: TextView
    private lateinit var startButton: Button
    private lateinit var strength: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updateUi(false)
    }

    private fun buildUi() {
        val pad = (22 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(0xFFF4F7F6.toInt())
        }
        fun text(value: String, size: Float, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(0xFF172B27.toInt())
                if (bold) setTypeface(null, Typeface.BOLD)
            }

        layout.addView(text("QuietEar", 30f, true))
        layout.addView(text("Filtragem experimental do som ambiente", 15f).apply {
            setPadding(0, 4, 0, pad)
        })
        status = text("Parado", 18f, true)
        layout.addView(status)
        layout.addView(text(
            "Intensidade da redução", 16f, true
        ).apply { setPadding(0, pad, 0, 0) })

        strength = SeekBar(this).apply {
            max = 100
            progress = 55
        }
        layout.addView(strength)
        level = text("55%", 14f)
        layout.addView(level)

        strength.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                level.text = "$progress%"
                engine?.setStrength(progress / 100f)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        startButton = Button(this).apply { text = "Iniciar filtragem" }
        startButton.setOnClickListener {
            if (engine == null) requestMicOrStart() else stopEngine()
        }
        layout.addView(startButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = pad })

        layout.addView(text(
            "Nota: esta versão é uma prova de conceito. Usa supressão de ruído do Android quando disponível e uma porta de ruído adaptativa. Não é ANC e não elimina todos os sons. Usa volume baixo e testa primeiro num local seguro.",
            13f
        ).apply { setPadding(0, pad, 0, 0) })

        layout.addView(text(
            "Modo Spotify: a aplicação não captura nem altera o áudio do Spotify. Tenta misturar o áudio filtrado com outras aplicações; o comportamento depende da versão do Android e das definições de áudio.",
            13f
        ).apply { setPadding(0, pad, 0, 0) })

        setContentView(layout)
    }

    private fun requestMicOrStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
        } else startEngine()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) startEngine()
        else Toast.makeText(this, "A permissão do microfone é necessária.", Toast.LENGTH_LONG).show()
    }

    private fun startEngine() {
        try {
            engine = QuietEarEngine(this, strength.progress / 100f).also { it.start() }
            updateUi(true)
        } catch (e: Exception) {
            engine = null
            status.text = "Não foi possível iniciar: ${e.message ?: "erro de áudio"}"
            Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
        }
    }

    private fun stopEngine() {
        engine?.stop()
        engine = null
        updateUi(false)
    }

    private fun updateUi(running: Boolean) {
        status.text = if (running) "Filtragem ativa" else "Parado"
        startButton.text = if (running) "Parar filtragem" else "Iniciar filtragem"
    }

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }
}

private class QuietEarEngine(
    private val context: Context,
    initialStrength: Float
) {
    companion object {
        private const val SAMPLE_RATE = 16000
    }

    @Volatile private var running = false
    @Volatile private var strength = initialStrength.coerceIn(0f, 1f)
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var suppressor: NoiseSuppressor? = null

    fun setStrength(value: Float) { strength = value.coerceIn(0f, 1f) }

    fun start() {
        val minIn = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val minOut = AudioTrack.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        require(minIn > 0 && minOut > 0) { "Formato de áudio não suportado" }
        val bufferSize = max(minIn, 2048) * 2

        val input = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )
        require(input.state == AudioRecord.STATE_INITIALIZED) { "Microfone indisponível" }

        val output = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(max(minOut, 2048) * 2)
            .build()
        require(output.state == AudioTrack.STATE_INITIALIZED) { "Saída de áudio indisponível" }

        recorder = input
        player = output

        if (NoiseSuppressor.isAvailable()) {
            try {
                suppressor = NoiseSuppressor.create(input.audioSessionId)?.apply { enabled = true }
            } catch (_: Exception) { suppressor = null }
        }

        running = true
        input.startRecording()
        output.play()

        worker = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val samples = ShortArray(1024)
            var noiseFloor = 180.0
            var envelope = 0.0
            while (running) {
                val count = input.read(samples, 0, samples.size)
                if (count <= 0) continue

                var sum = 0.0
                for (i in 0 until count) {
                    val v = samples[i].toDouble()
                    sum += v * v
                }
                val rms = sqrt(sum / count)
                // Estimate slowly varying background level; avoid tracking sudden loud events.
                if (rms < noiseFloor * 2.2) noiseFloor = noiseFloor * 0.995 + rms * 0.005
                val threshold = noiseFloor * (1.0 + strength * 2.5)
                val targetGain = when {
                    rms < threshold -> 1.0 - strength * 0.88
                    rms < threshold * 2.0 -> 1.0 - strength * 0.35
                    else -> 1.0
                }
                // Smooth gain to reduce clicks. This is a simple gate, not source separation.
                for (i in 0 until count) {
                    envelope += (targetGain - envelope) * 0.025
                    val out = (samples[i] * envelope).toInt().coerceIn(-32768, 32767)
                    samples[i] = out.toShort()
                }
                output.write(samples, 0, count, AudioTrack.WRITE_BLOCKING)
            }
        }.apply { name = "QuietEar-Audio"; start() }
    }

    fun stop() {
        running = false
        try { worker?.join(500) } catch (_: InterruptedException) {}
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        try { suppressor?.release() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        worker = null
        recorder = null
        player = null
        suppressor = null
    }
}
